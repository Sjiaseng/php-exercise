<?php
session_start();

if(isset($_SESSION["member_id"])){
	
	if ($_SESSION["member_role"] != "admin") {
		echo "<script>alert('You are not admin!');window.location.href='logout.php';</script>";
	}
	
	echo $_SESSION["member_id"] . " " . $_SESSION["fullname"] . " Role: ".$_SESSION["member_role"];
}
else {
	echo "session not set";
	echo "<script>alert('Please Login!');window.location.href='login.php';</script>";
}


?>
<a href="logout.php">Logout</a>